var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var JsonUtilityComamnd;
(function (JsonUtilityComamnd) {
    var JsonDeserializeCommand = /** @class */ (function (_super) {
        __extends(JsonDeserializeCommand, _super);
        function JsonDeserializeCommand() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        JsonDeserializeCommand.prototype.execute = function () {
            var commandSettings = this.CommandParam;
            var jsonString = this.evaluateFormula(commandSettings.JsonString);
            // 处理解析时换行符报错
            jsonString = jsonString.replace(/\n/g, '').replace(/\r/g, '');
            if (commandSettings.ToParameter) {
                var value = jsonString === "" ? null : JSON.parse(jsonString);
                Forguncy.CommandHelper.setVariableValue(commandSettings.ToParameter, value);
            }
        };
        return JsonDeserializeCommand;
    }(Forguncy.Plugin.CommandBase));
    JsonUtilityComamnd.JsonDeserializeCommand = JsonDeserializeCommand;
    var JsonSerializeCommand = /** @class */ (function (_super) {
        __extends(JsonSerializeCommand, _super);
        function JsonSerializeCommand() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        JsonSerializeCommand.prototype.execute = function () {
            var commandSettings = this.CommandParam;
            var object = this.evaluateFormula(commandSettings.SourceObject);
            if (commandSettings.ToParameter) {
                var value = JSON.stringify(object);
                Forguncy.CommandHelper.setVariableValue(commandSettings.ToParameter, value);
            }
        };
        return JsonSerializeCommand;
    }(Forguncy.Plugin.CommandBase));
    JsonUtilityComamnd.JsonSerializeCommand = JsonSerializeCommand;
})(JsonUtilityComamnd || (JsonUtilityComamnd = {}));
Forguncy.Plugin.CommandFactory.registerCommand("JsonUtilityCommand.JsonDeserializeCommand, JsonUtilityCommand", JsonUtilityComamnd.JsonDeserializeCommand);
Forguncy.Plugin.CommandFactory.registerCommand("JsonUtilityCommand.JsonSerializeCommand, JsonUtilityCommand", JsonUtilityComamnd.JsonSerializeCommand);
//# sourceMappingURL=JsonUtilityCommand.js.map