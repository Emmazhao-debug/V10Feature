﻿var RS_JP = {
    Error_DetailInfo: "CSVファイルの {1} 行目の値 {0} が不正な値です。\r\nエラーメッセージ：{2}",
    Error_ColumnNameNotMatch: "次の列名がCSVファイルの最初の行に存在しません。：［{0}］",
    Error_ExistSameKeys: "Ensure that the column(s) specified to identify a record uniquely don't have duplicated values in the CSV document.\r\nDuplicated values are as follows: {0}.",
    Error_ExistEmptyKeys: "There is blank data in the base column in the CSV file, please ensure that the data in the base column is not empty. \r\nThe line where the blank value is located is as follows: {0}.",
    Error_ListViewDataExistEmptyKeys: "There is blank data in the base column in the listview '{0}', please ensure that the data in the base column is not empty. \r\nThe line where the blank value is located is as follows: {1}.",
};

var RS_CN = {
    Error_DetailInfo: "CSV文件中第'{1}'行中的值'{0}'不合法；\r\n错误信息：{2}",
    Error_ColumnNameNotMatch: "CSV文件第一行中未发现以下列名：【{0}】。",
    Error_ExistSameKeys: "CSV文件中基准列存在相同数据，请确保基准列的数据唯一。\r\n重复值如下所示: {0}",
    Error_ExistEmptyKeys: "CSV文件中基准列存在空白数据，请确保基准列的数据非空。\r\n空白值所在行如下所示: {0}",
    Error_ListViewDataExistEmptyKeys: "表格'{0}'中基准列存在空白数据，请确保基准列的数据非空。\r\n空白值所在行如下所示: {1}",
};

var RS_KO = {
    Error_DetailInfo: "CSV 파일의 '{1}'행에있는 '{0}'값이 잘못되었습니다.\r\nError message:{2}",
    Error_ColumnNameNotMatch: "CSV 파일의 첫 번째 행에 이러한 열 이름을 찾을 수 없습니다.:[{0}].",
    Error_ExistSameKeys: "Ensure that the column(s) specified to identify a record uniquely don't have duplicated values in the CSV document.\r\nDuplicated values are as follows: {0}.",
    Error_ExistEmptyKeys: "There is blank data in the base column in the CSV file, please ensure that the data in the base column is not empty. \r\nThe line where the blank value is located is as follows: {0}.",
    Error_ListViewDataExistEmptyKeys: "There is blank data in the base column in the listview '{0}', please ensure that the data in the base column is not empty. \r\nThe line where the blank value is located is as follows: {1}.",
};

var RS_EN = {
    Error_DetailInfo: "The value '{0}' is invalid which in row '{1}' in csv file.\r\nError message:{2}",
    Error_ColumnNameNotMatch: "Not found such column names in first row of csv file:[{0}].",
    Error_ExistSameKeys: "Ensure that the column(s) specified to identify a record uniquely don't have duplicated values in the CSV document.\r\nDuplicated values are as follows: {0}.",
    Error_ExistEmptyKeys: "There is blank data in the base column in the CSV file, please ensure that the data in the base column is not empty. \r\nThe line where the blank value is located is as follows: {0}.",
    Error_ListViewDataExistEmptyKeys: "There is blank data in the base column in the listview '{0}', please ensure that the data in the base column is not empty. \r\nThe line where the blank value is located is as follows: {1}.",
};